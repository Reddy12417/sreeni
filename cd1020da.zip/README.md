# Salesforce Automation Framework

[![Tests](https://github.com/your-org/salesforce-automation-framework/workflows/Tests/badge.svg)](https://github.com/your-org/salesforce-automation-framework/actions)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

A comprehensive automation testing framework for Salesforce applications using **Playwright**, **TypeScript**, and **Cucumber BDD**. Specifically designed for CNA Hardy's Salesforce cloud application with insurance domain expertise.

## 🚀 Quick Start

### Prerequisites
- **Node.js** (v16 or higher)
- **npm** or **yarn**
- **Salesforce org** with API access
- **Connected App** configured in Salesforce

### Installation

1. **Clone/Extract the framework**
   ```bash
   cd salesforce-automation-framework
   ```

2. **Install dependencies**
   ```bash
   npm run setup
   ```

3. **Configure environment**
   ```bash
   cp .env.template .env
   # Edit .env with your Salesforce credentials
   ```

4. **Run sample tests**
   ```bash
   npm run test:smoke
   ```

## 📁 Framework Architecture

```
salesforce-automation-framework/
├── src/
│   ├── features/           # Gherkin feature files
│   │   ├── ui/            # UI test scenarios
│   │   └── api/           # API test scenarios
│   ├── step-definitions/   # Cucumber step implementations
│   │   ├── ui-steps/      # UI step definitions
│   │   └── api-steps/     # API step definitions
│   ├── pages/             # Page Object Models
│   ├── services/          # API service layer
│   ├── utils/             # Helper utilities
│   ├── fixtures/          # Test data (environment-specific)
│   └── support/           # Cucumber hooks and world setup
├── config/                # Configuration files
├── reports/               # Test execution reports
└── .github/workflows/     # CI/CD configuration
```

## 🎯 Key Features

### ✅ **Hybrid Testing Approach**
- **UI Testing**: Playwright-based Lightning component automation
- **API Testing**: Salesforce REST API integration
- **Integration Testing**: API setup with UI validation

### ✅ **Environment Management**
- **Multi-environment support**: dev, staging, production
- **Environment-specific configuration**: URLs, timeouts, data
- **Secure credential management**: Environment variables

### ✅ **Salesforce Optimization**
- **Lightning Web Components**: Specialized selectors and wait strategies
- **Dynamic DOM handling**: Proper wait for Lightning spinners
- **Toast message validation**: Success/error message verification
- **Navigation utilities**: App launcher and object navigation

### ✅ **Test Data Management**
- **Dynamic data generation**: Faker.js integration
- **Environment-specific data**: Different data sets per environment
- **Insurance domain objects**: Policies, accounts, claims, contacts
- **Automatic cleanup**: Test data removal after execution

### ✅ **Business-Driven Testing**
- **Cucumber BDD**: Business-readable scenarios
- **Gherkin syntax**: Clear feature specifications
- **Reusable steps**: Modular test components
- **Data tables**: Parameterized testing

## 📋 Test Execution

### Basic Commands

```bash
# Run all tests
npm test

# Environment-specific testing
npm run test:dev
npm run test:staging
npm run test:prod

# Test type specific
npm run test:ui          # UI tests only
npm run test:api         # API tests only
npm run test:smoke       # Smoke tests
npm run test:regression  # Full regression

# Advanced options
npm run test:headed      # Visible browser
npm run test:parallel    # Parallel execution
```

### Environment Configuration

Set environment via environment variable:
```bash
export TEST_ENV=dev      # or staging, prod
```

Or use npm scripts:
```bash
TEST_ENV=staging npm run test:smoke
```

## 🔧 Configuration

### Environment Variables (.env)

```bash
# Development Environment
DEV_CLIENT_ID=your_salesforce_connected_app_client_id
DEV_CLIENT_SECRET=your_salesforce_connected_app_client_secret
DEV_USERNAME=your_salesforce_username@example.com
DEV_PASSWORD=your_salesforce_password
DEV_SECURITY_TOKEN=your_salesforce_security_token

# Staging Environment
STAGING_CLIENT_ID=your_staging_client_id
STAGING_CLIENT_SECRET=your_staging_client_secret
STAGING_USERNAME=your_staging_username@example.com
STAGING_PASSWORD=your_staging_password
STAGING_SECURITY_TOKEN=your_staging_security_token

# Test Configuration
TEST_ENV=dev
HEADLESS=false
PARALLEL_WORKERS=2
```

### Salesforce Setup

1. **Create Connected App** in Salesforce Setup
2. **Enable OAuth Settings**:
   - Callback URL: `http://localhost:3000/callback`
   - Selected OAuth Scopes: `Full access (full)`, `Perform requests on your behalf at any time (refresh_token, offline_access)`
3. **Get Client ID and Secret** from Connected App
4. **Generate Security Token** for your user

## 📊 Sample Test Scenarios

### UI Test Example

```gherkin
Feature: Insurance Policy Management
  @smoke @policy-creation
  Scenario: Create new property insurance policy
    Given I am logged into CNA Hardy Salesforce application
    And I navigate to the Policy Management application
    When I create a property insurance policy with the following details:
      | Policy Type     | Property  |
      | Coverage Amount | 1500000   |
      | Deductible     | 5000      |
    Then the policy should be created successfully
    And I should see a success confirmation message
```

### API Test Example

```gherkin
Feature: Salesforce REST API Operations
  @api @account-management
  Scenario: Create and retrieve Account via REST API
    When I send a POST request to create an Account with the following data:
      | Name     | CNA Hardy Test Insurance Co |
      | Type     | Customer                    |
      | Industry | Insurance                   |
    Then the API response status should be 201
    And I should be able to retrieve the account details
```

### Integration Test Example

```gherkin
Feature: API-UI Integration
  @integration
  Scenario: API created policy appears in UI
    Given I create a policy via API with name "API-INTEGRATION-TEST"
    When I search for the policy in Salesforce user interface
    Then I should find the policy record in the UI search results
    And all API-created fields should be properly displayed
```

## 🧪 Writing Tests

### Feature Files Structure

```gherkin
Feature: [Feature Name]
  Background:
    Given [Common setup steps]

  @tag1 @tag2
  Scenario: [Scenario description]
    Given [Preconditions]
    When [Actions]
    Then [Expected results]
```

### Step Definition Example

```typescript
When('I create a policy with coverage amount {string}', 
async function(this: World, amount: string) {
  const policyData = DataFactory.createPolicy({
    Coverage_Amount__c: parseInt(amount)
  });

  const policyId = await this.policyPage.createPolicy(policyData);
  this.addCreatedRecord('Policy__c', policyId);
});
```

### Page Object Example

```typescript
export class PolicyPage extends BasePage {
  async createPolicy(policyData: PolicyData): Promise<string> {
    await this.fillInput('Name', policyData.Name);
    await this.selectFromCombobox('Policy Type', policyData.Policy_Type__c);
    await this.fillInput('Coverage Amount', policyData.Coverage_Amount__c.toString());
    await this.clickButton('Save');
    return this.extractRecordId();
  }
}
```

## 🏗️ Insurance Domain Features

### Business Objects
- **Policies**: Property, Casualty, Auto insurance policies
- **Claims**: Claim submission and processing workflows
- **Accounts**: Customer and prospect management
- **Contacts**: Policyholder and beneficiary information

### Sample Test Scenarios
- **Policy Lifecycle**: Creation, renewal, cancellation
- **Claims Processing**: Submission, approval, settlement
- **Underwriting**: Risk assessment workflows
- **Regulatory Compliance**: Validation and reporting

## 📈 Reporting

### Available Reports
- **HTML Report**: `reports/cucumber-report.html`
- **JSON Report**: `reports/cucumber-report.json`
- **Playwright Report**: `reports/playwright-report/`
- **Screenshots**: `reports/screenshots/` (on failures)

### CI/CD Integration

**GitHub Actions workflow included**:
- Parallel test execution
- Environment matrix testing
- Artifact collection
- Failure notifications

## 🔍 Debugging

### Debug Commands

```bash
# Run with debug output
DEBUG=* npm test

# Run single scenario
npm test -- --name "Create new policy"

# Run with traces
TRACE=on npm test

# Run in headed mode
npm run test:headed
```

### Common Issues

1. **Authentication Failed**
   - Verify credentials in `.env` file
   - Check security token is current
   - Ensure Connected App is properly configured

2. **Element Not Found**
   - Lightning components may have dynamic selectors
   - Use proper wait strategies
   - Check for Lightning spinners

3. **Timeout Errors**
   - Increase timeouts in environment configuration
   - Verify network connectivity
   - Check for slow-loading pages

## 🛠️ Best Practices

### Test Independence
- Each scenario should be independent
- Use proper setup and cleanup
- Avoid dependencies between tests

### Data Management
- Use dynamic test data generation
- Clean up test data after execution
- Separate data by environment

### Wait Strategies
- Use smart waits, avoid hard sleeps
- Wait for Lightning spinners to disappear
- Use Playwright's built-in wait methods

### Error Handling
- Implement comprehensive error handling
- Capture screenshots on failures
- Provide meaningful error messages

## 🤝 Contributing

1. Follow TypeScript and ESLint standards
2. Write clear, descriptive test scenarios
3. Update documentation for new features
4. Ensure all tests pass before committing
5. Use conventional commit messages

## 📞 Support

### Resources
- **Salesforce Trailhead**: Lightning testing best practices
- **Playwright Documentation**: https://playwright.dev
- **Cucumber Documentation**: https://cucumber.io

### Troubleshooting
1. Check environment configuration
2. Verify Salesforce permissions
3. Review error logs and screenshots
4. Use debug mode for detailed output

---

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

**Happy Testing! 🎉**

Built with ❤️ for CNA Hardy's Salesforce automation needs.

import { defineConfig, devices } from '@playwright/test';
import { getEnvironmentConfig } from './environments';

const envConfig = getEnvironmentConfig();

export default defineConfig({
  testDir: '../src/step-definitions',
  timeout: envConfig.timeout.default,
  retries: envConfig.retryAttempts,
  workers: process.env.CI ? 2 : process.env.PARALLEL_WORKERS ? parseInt(process.env.PARALLEL_WORKERS) : 1,

  use: {
    baseURL: envConfig.webUrl,
    headless: envConfig.headless,
    slowMo: envConfig.slowMo,
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
    trace: 'retain-on-failure',
    actionTimeout: 15000,
    navigationTimeout: envConfig.timeout.navigation,
  },

  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    }
  ],

  reporter: [
    ['html', { outputFolder: '../reports/playwright-report' }],
    ['json', { outputFile: '../reports/test-results.json' }],
    ['list']
  ],
});
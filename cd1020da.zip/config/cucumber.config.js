const { setDefaultTimeout } = require('@cucumber/cucumber');

setDefaultTimeout(60 * 1000);

module.exports = {
  default: {
    require: [
      'src/step-definitions/**/*.ts',
      'src/support/**/*.ts'
    ],
    requireModule: ['ts-node/register'],
    format: [
      'pretty',
      'html:reports/cucumber-report.html',
      'json:reports/cucumber-report.json'
    ],
    formatOptions: {
      snippetInterface: 'async-await'
    },
    paths: ['src/features/**/*.feature'],
    tags: process.env.TAGS || '',
    parallel: process.env.PARALLEL_WORKERS ? parseInt(process.env.PARALLEL_WORKERS) : 1
  }
};
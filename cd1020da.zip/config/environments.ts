// Environment configuration for different Salesforce orgs
export interface EnvironmentConfig {
  name: string;
  webUrl: string;
  authUrl: string;
  apiUrl: string;
  dataPath: string;
  timeout: {
    default: number;
    api: number;
    navigation: number;
  };
  retryAttempts: number;
  headless: boolean;
  slowMo: number;
}

export const environments: Record<string, EnvironmentConfig> = {
  dev: {
    name: 'Development',
    webUrl: 'https://cnahardy-dev.lightning.force.com',
    authUrl: 'https://test.salesforce.com/services/oauth2/token',
    apiUrl: 'https://cnahardy-dev.my.salesforce.com',
    dataPath: 'src/fixtures/dev',
    timeout: {
      default: 30000,
      api: 60000,
      navigation: 45000
    },
    retryAttempts: 2,
    headless: process.env.HEADLESS === 'true',
    slowMo: 500
  },
  staging: {
    name: 'Staging',
    webUrl: 'https://cnahardy-staging.lightning.force.com',
    authUrl: 'https://test.salesforce.com/services/oauth2/token',
    apiUrl: 'https://cnahardy-staging.my.salesforce.com',
    dataPath: 'src/fixtures/staging',
    timeout: {
      default: 30000,
      api: 60000,
      navigation: 45000
    },
    retryAttempts: 3,
    headless: true,
    slowMo: 100
  },
  prod: {
    name: 'Production',
    webUrl: 'https://cnahardy.lightning.force.com',
    authUrl: 'https://login.salesforce.com/services/oauth2/token',
    apiUrl: 'https://cnahardy.my.salesforce.com',
    dataPath: 'src/fixtures/prod',
    timeout: {
      default: 45000,
      api: 90000,
      navigation: 60000
    },
    retryAttempts: 1,
    headless: true,
    slowMo: 0
  }
};

export function getEnvironmentConfig(envName?: string): EnvironmentConfig {
  const env = envName || process.env.TEST_ENV || 'dev';

  if (!environments[env]) {
    throw new Error(`Environment '${env}' not found. Available: ${Object.keys(environments).join(', ')}`);
  }

  return environments[env];
}

export function validateEnvironmentVariables(env: string): void {
  const requiredVars = [
    `${env.toUpperCase()}_CLIENT_ID`,
    `${env.toUpperCase()}_CLIENT_SECRET`,
    `${env.toUpperCase()}_USERNAME`,
    `${env.toUpperCase()}_PASSWORD`,
    `${env.toUpperCase()}_SECURITY_TOKEN`
  ];

  const missingVars = requiredVars.filter(varName => !process.env[varName]);

  if (missingVars.length > 0) {
    console.warn(`Missing environment variables: ${missingVars.join(', ')}`);
  }
}
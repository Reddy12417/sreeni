#!/bin/bash
# Test execution script with different options

show_usage() {
    echo "Usage: $0 {smoke|regression|ui|api|parallel|headed|dev|staging}"
    echo ""
    echo "Test Suites:"
    echo "  smoke      - Quick smoke tests (recommended for CI)"
    echo "  regression - Full regression test suite"
    echo "  ui         - User interface tests only"
    echo "  api        - API tests only"
    echo "  parallel   - Run tests in parallel"
    echo "  headed     - Run with visible browser"
    echo ""
    echo "Environments:"
    echo "  dev        - Development environment"
    echo "  staging    - Staging environment"
    echo ""
    echo "Examples:"
    echo "  $0 smoke           # Run smoke tests in default environment"
    echo "  $0 ui              # Run UI tests"
    echo "  TEST_ENV=staging $0 smoke  # Run smoke tests in staging"
}

case "$1" in
    "smoke")
        echo "🧪 Running smoke tests..."
        npm run test:smoke
        ;;
    "regression")
        echo "🔄 Running regression tests..."
        npm run test:regression
        ;;
    "ui")
        echo "🖥️  Running UI tests..."
        npm run test:ui
        ;;
    "api")
        echo "🔌 Running API tests..."
        npm run test:api
        ;;
    "parallel")
        echo "⚡ Running tests in parallel..."
        npm run test:parallel
        ;;
    "headed")
        echo "👀 Running tests in headed mode..."
        npm run test:headed
        ;;
    "dev")
        echo "🛠️  Running tests in development environment..."  
        TEST_ENV=dev npm run test:smoke
        ;;
    "staging")
        echo "🔬 Running tests in staging environment..."
        TEST_ENV=staging npm run test:smoke
        ;;
    *)
        show_usage
        exit 1
        ;;
esac

exit_code=$?

if [ $exit_code -eq 0 ]; then
    echo "✅ Tests completed successfully!"
else
    echo "❌ Tests failed with exit code $exit_code"
    echo "Check reports/ directory for details"
fi

exit $exit_code

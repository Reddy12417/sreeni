#!/bin/bash
# Setup script for Salesforce Automation Framework

echo "🚀 Setting up Salesforce Automation Framework..."

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js 16+ first."
    echo "Visit: https://nodejs.org/"
    exit 1
fi

echo "✅ Node.js version: $(node --version)"

# Check if npm is installed
if ! command -v npm &> /dev/null; then
    echo "❌ npm is not installed. Please install npm first."
    exit 1
fi

echo "✅ npm version: $(npm --version)"

# Install dependencies
echo "📦 Installing dependencies..."
npm install

if [ $? -ne 0 ]; then
    echo "❌ Failed to install dependencies"
    exit 1
fi

# Install Playwright browsers
echo "🎭 Installing Playwright browsers..."
npx playwright install --with-deps chromium

if [ $? -ne 0 ]; then
    echo "❌ Failed to install Playwright browsers"
    exit 1
fi

# Create .env file from template if it doesn't exist
if [ ! -f .env ]; then
    echo "⚙️  Creating .env file from template..."
    cp .env.template .env
    echo "📝 Please edit .env file with your Salesforce credentials"
else
    echo "✅ .env file already exists"
fi

# Create necessary directories
mkdir -p reports/screenshots reports/videos test-results

echo ""
echo "🎉 Setup complete!"
echo ""
echo "Next steps:"
echo "1. Edit .env file with your Salesforce credentials"
echo "2. Run 'npm run test:smoke' to verify setup"
echo "3. Check README.md for detailed usage instructions"
echo ""
echo "Quick test commands:"
echo "  npm run test:smoke    # Run smoke tests"
echo "  npm run test:ui       # Run UI tests"
echo "  npm run test:api      # Run API tests"
echo "  npm run test:headed   # Run with visible browser"

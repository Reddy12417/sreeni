import { Before, After, BeforeAll, AfterAll, Status } from '@cucumber/cucumber';
import { chromium, Browser } from '@playwright/test';
import { World } from './world';
import { SalesforceApiHelpers } from '../utils/api-helpers';
import { getEnvironmentConfig, validateEnvironmentVariables } from '../../config/environments';
import * as dotenv from 'dotenv';

dotenv.config();

let browser: Browser;

BeforeAll(async function () {
  const env = process.env.TEST_ENV || 'dev';
  validateEnvironmentVariables(env);

  const envConfig = getEnvironmentConfig();
  browser = await chromium.launch({
    headless: envConfig.headless,
    slowMo: envConfig.slowMo
  });

  console.log(`🚀 Starting tests on ${envConfig.name} environment`);
});

Before(async function (this: World, { pickle }) {
  this.context = await browser.newContext({
    viewport: { width: 1280, height: 720 },
  });
  this.page = await this.context.newPage();

  const envConfig = getEnvironmentConfig();
  this.page.setDefaultTimeout(envConfig.timeout.default);
  this.page.setDefaultNavigationTimeout(envConfig.timeout.navigation);

  console.log(`📝 Starting: ${pickle.name}`);
});

After(async function (this: World, { result, pickle }) {
  if (result?.status === Status.FAILED) {
    const screenshot = await this.page.screenshot({ 
      path: `reports/screenshots/failed-${pickle.name.replace(/\s+/g, '-')}-${Date.now()}.png`,
      fullPage: true 
    });
    this.attach(screenshot, 'image/png');
  }

  // Cleanup test records
  if (this.createdRecords.length > 0) {
    try {
      const apiContext = await this.apiClient.getApiContext();
      const auth = await this.apiClient.getAuthInfo();
      await SalesforceApiHelpers.cleanupTestData(apiContext, this.createdRecords, auth.instance_url);
      console.log(`🧹 Cleaned up ${this.createdRecords.length} records`);
    } catch (error) {
      console.warn(`⚠️ Cleanup failed: ${error}`);
    }
  }

  await this.context.close();
  console.log(`✅ Completed: ${pickle.name}`);
});

AfterAll(async function () {
  await browser.close();
  console.log('🏁 Test execution completed');
});
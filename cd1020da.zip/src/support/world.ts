import { IWorldOptions, World as BaseWorld, setWorldConstructor } from '@cucumber/cucumber';
import { Page, APIResponse, Browser, BrowserContext } from '@playwright/test';
import { ApiClient } from '../services/api-client';

export interface TestRecord {
  sobjectType: string;
  recordId: string;
}

export class World extends BaseWorld {
  // Browser testing
  browser!: Browser;
  context!: BrowserContext;
  page!: Page;

  // API testing
  apiClient: ApiClient;
  apiResponse!: APIResponse;

  // Test data management
  createdRecords: TestRecord[] = [];
  testData: Map<string, any> = new Map();

  constructor(options: IWorldOptions) {
    super(options);
    this.apiClient = new ApiClient();
  }

  addCreatedRecord(sobjectType: string, recordId: string): void {
    this.createdRecords.push({ sobjectType, recordId });
  }

  setTestData(key: string, value: any): void {
    this.testData.set(key, value);
  }

  getTestData(key: string): any {
    return this.testData.get(key);
  }
}

setWorldConstructor(World);
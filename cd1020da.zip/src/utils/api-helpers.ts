import { APIRequestContext, APIResponse } from '@playwright/test';

export interface SObjectRecord {
  Id?: string;
  [key: string]: any;
}

export class SalesforceApiHelpers {

  static async query(apiContext: APIRequestContext, soql: string, instanceUrl: string): Promise<any> {
    const encodedQuery = encodeURIComponent(soql);
    const response = await apiContext.get(`${instanceUrl}/services/data/v58.0/query/?q=${encodedQuery}`);

    if (!response.ok()) {
      throw new Error(`Query failed: ${response.status()} ${await response.text()}`);
    }

    return await response.json();
  }

  static async createRecord(
    apiContext: APIRequestContext, 
    sobjectType: string, 
    recordData: SObjectRecord,
    instanceUrl: string
  ): Promise<{ id: string; success: boolean; errors: any[] }> {
    const response = await apiContext.post(`${instanceUrl}/services/data/v58.0/sobjects/${sobjectType}/`, {
      data: recordData
    });

    if (!response.ok()) {
      throw new Error(`Create record failed: ${response.status()} ${await response.text()}`);
    }

    return await response.json();
  }

  static async updateRecord(
    apiContext: APIRequestContext,
    sobjectType: string,
    recordId: string,
    recordData: SObjectRecord,
    instanceUrl: string
  ): Promise<void> {
    const response = await apiContext.patch(`${instanceUrl}/services/data/v58.0/sobjects/${sobjectType}/${recordId}`, {
      data: recordData
    });

    if (!response.ok()) {
      throw new Error(`Update record failed: ${response.status()} ${await response.text()}`);
    }
  }

  static async deleteRecord(
    apiContext: APIRequestContext,
    sobjectType: string,
    recordId: string,
    instanceUrl: string
  ): Promise<void> {
    const response = await apiContext.delete(`${instanceUrl}/services/data/v58.0/sobjects/${sobjectType}/${recordId}`);

    if (!response.ok()) {
      console.warn(`Delete record failed: ${response.status()}`);
    }
  }

  static async getRecord(
    apiContext: APIRequestContext,
    sobjectType: string,
    recordId: string,
    fields: string[],
    instanceUrl: string
  ): Promise<SObjectRecord> {
    const fieldsParam = fields.join(',');
    const response = await apiContext.get(`${instanceUrl}/services/data/v58.0/sobjects/${sobjectType}/${recordId}?fields=${fieldsParam}`);

    if (!response.ok()) {
      throw new Error(`Get record failed: ${response.status()} ${await response.text()}`);
    }

    return await response.json();
  }

  static async createBulkRecords(
    apiContext: APIRequestContext,
    sobjectType: string,
    records: SObjectRecord[],
    instanceUrl: string
  ): Promise<any[]> {
    const compositeRequest = {
      allOrNone: false,
      compositeRequest: records.map((record, index) => ({
        method: 'POST',
        url: `/services/data/v58.0/sobjects/${sobjectType}/`,
        referenceId: `ref${index}`,
        body: record
      }))
    };

    const response = await apiContext.post(`${instanceUrl}/services/data/v58.0/composite/`, {
      data: compositeRequest
    });

    if (!response.ok()) {
      throw new Error(`Bulk create failed: ${response.status()} ${await response.text()}`);
    }

    const result = await response.json();
    return result.compositeResponse;
  }

  static async findRecordByField(
    apiContext: APIRequestContext,
    sobjectType: string,
    fieldName: string,
    fieldValue: string,
    instanceUrl: string
  ): Promise<SObjectRecord | null> {
    const soql = `SELECT Id, Name FROM ${sobjectType} WHERE ${fieldName} = '${fieldValue}' LIMIT 1`;
    const result = await this.query(apiContext, soql, instanceUrl);

    return result.records.length > 0 ? result.records[0] : null;
  }

  static async cleanupTestData(
    apiContext: APIRequestContext,
    testRecords: Array<{ sobjectType: string; recordId: string }>,
    instanceUrl: string
  ): Promise<void> {
    const cleanupPromises = testRecords.map(({ sobjectType, recordId }) =>
      this.deleteRecord(apiContext, sobjectType, recordId, instanceUrl).catch(error => {
        console.warn(`Failed to cleanup record ${recordId}: ${error.message}`);
      })
    );

    await Promise.all(cleanupPromises);
  }
}
import { faker } from '@faker-js/faker';
import { DataLoader } from './data-loader';

export interface UserData {
  username: string;
  password: string;
  email: string;
  firstName: string;
  lastName: string;
  role: string;
}

export interface PolicyData {
  Name: string;
  Policy_Type__c: 'Property' | 'Casualty' | 'Auto';
  Coverage_Amount__c: number;
  Deductible__c: number;
  Effective_Date__c: string;
  Expiration_Date__c: string;
  Status__c: 'Active' | 'Pending' | 'Cancelled';
}

export interface AccountData {
  Name: string;
  Type: string;
  Industry: string;
  Phone?: string;
  Website?: string;
}

export class DataFactory {
  private static getEnvironmentData<T>(fileName: string): T {
    try {
      const env = process.env.TEST_ENV || 'dev';
      return DataLoader.load<T>(fileName, env);
    } catch {
      // Return empty object if file doesn't exist
      return {} as T;
    }
  }

  static createUser(overrides: Partial<UserData> = {}): UserData {
    const baseUser = this.getEnvironmentData<Partial<UserData>>('users');

    return {
      username: `test_${faker.internet.userName()}@example.com`,
      password: 'TestPassword123!',
      email: faker.internet.email(),
      firstName: faker.person.firstName(),
      lastName: faker.person.lastName(),
      role: 'Standard User',
      ...baseUser,
      ...overrides
    };
  }

  static createAccount(overrides: Partial<AccountData> = {}): AccountData {
    return {
      Name: `${faker.company.name()} ${faker.string.alphanumeric(4)}`,
      Type: faker.helpers.arrayElement(['Customer', 'Partner', 'Prospect']),
      Industry: faker.helpers.arrayElement(['Insurance', 'Financial Services', 'Technology']),
      Phone: faker.phone.number(),
      Website: faker.internet.url(),
      ...overrides
    };
  }

  static createPolicy(overrides: Partial<PolicyData> = {}): PolicyData {
    const effectiveDate = faker.date.future();
    const expirationDate = new Date(effectiveDate);
    expirationDate.setFullYear(expirationDate.getFullYear() + 1);

    return {
      Name: `POL-${faker.string.alphanumeric(8).toUpperCase()}`,
      Policy_Type__c: faker.helpers.arrayElement(['Property', 'Casualty', 'Auto'] as const),
      Coverage_Amount__c: faker.number.int({ min: 100000, max: 2000000 }),
      Deductible__c: faker.helpers.arrayElement([500, 1000, 2500, 5000]),
      Effective_Date__c: effectiveDate.toISOString().split('T')[0],
      Expiration_Date__c: expirationDate.toISOString().split('T')[0],
      Status__c: 'Active',
      ...overrides
    };
  }

  static createContact(accountId?: string, overrides: any = {}): any {
    return {
      FirstName: faker.person.firstName(),
      LastName: faker.person.lastName(),
      Email: faker.internet.email(),
      Phone: faker.phone.number(),
      Title: faker.person.jobTitle(),
      AccountId: accountId,
      ...overrides
    };
  }

  static createTestScenario(scenarioType: 'new-customer' | 'renewal' | 'claim'): any {
    const account = this.createAccount();
    const policy = this.createPolicy();

    switch (scenarioType) {
      case 'new-customer':
        return {
          account,
          policy: { ...policy, Status__c: 'Pending' },
          testType: 'new-customer-flow'
        };
      case 'renewal':
        return {
          account,
          policy: { 
            ...policy, 
            Expiration_Date__c: faker.date.soon({ days: 30 }).toISOString().split('T')[0]
          },
          testType: 'renewal-flow'
        };
      case 'claim':
        return {
          account,
          policy,
          claim: {
            Claim_Number__c: `CLM-${faker.string.alphanumeric(8).toUpperCase()}`,
            Incident_Date__c: faker.date.recent().toISOString().split('T')[0],
            Claim_Amount__c: faker.number.int({ min: 1000, max: 50000 }),
            Status__c: 'Open'
          },
          testType: 'claim-flow'
        };
      default:
        throw new Error(`Unknown scenario type: ${scenarioType}`);
    }
  }

  static createBulkData<T>(factory: () => T, count: number): T[] {
    return Array.from({ length: count }, () => factory());
  }
}
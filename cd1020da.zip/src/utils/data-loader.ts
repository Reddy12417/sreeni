import { readFileSync, existsSync } from 'fs';
import { join } from 'path';

export class DataLoader {
  private static cache = new Map<string, any>();

  static load<T>(fileName: string, environment?: string): T {
    const env = environment || process.env.TEST_ENV || 'dev';
    const cacheKey = `${env}:${fileName}`;

    if (this.cache.has(cacheKey)) {
      return this.cache.get(cacheKey);
    }

    const envFilePath = join(process.cwd(), 'src', 'fixtures', env, `${fileName}.json`);

    if (!existsSync(envFilePath)) {
      throw new Error(`Data file not found: ${envFilePath}`);
    }

    try {
      const data = JSON.parse(readFileSync(envFilePath, 'utf-8'));
      this.cache.set(cacheKey, data);
      return data as T;
    } catch (error) {
      throw new Error(`Failed to load data from ${envFilePath}: ${error}`);
    }
  }

  static clearCache(): void {
    this.cache.clear();
  }
}
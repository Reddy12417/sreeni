import { Page, Locator, expect } from '@playwright/test';

export class SalesforceHelpers {

  static async waitForLightningSpinner(page: Page, timeout: number = 30000): Promise<void> {
    try {
      await page.waitForSelector('.slds-spinner', { state: 'attached', timeout: 5000 });
    } catch {
      // Spinner might not appear
    }

    await page.waitForSelector('.slds-spinner', { state: 'detached', timeout });
  }

  static async waitForPageLoad(page: Page): Promise<void> {
    await page.waitForLoadState('networkidle');
    await this.waitForLightningSpinner(page);
    await page.waitForSelector('[data-aura-rendered-by], lightning-card, .slds-card', { timeout: 10000 });
  }

  static async clickLightningButton(page: Page, buttonText: string): Promise<void> {
    const selectors = [
      `lightning-button button:has-text("${buttonText}")`,
      `button:has-text("${buttonText}")`,
      `input[value="${buttonText}"]`
    ];

    for (const selector of selectors) {
      try {
        const element = page.locator(selector).first();
        await element.waitFor({ state: 'visible', timeout: 5000 });
        await element.click();
        await this.waitForLightningSpinner(page);
        return;
      } catch {
        continue;
      }
    }

    throw new Error(`Button with text "${buttonText}" not found`);
  }

  static async fillLightningInput(page: Page, label: string, value: string): Promise<void> {
    const selectors = [
      `lightning-input[data-field="${label}"] input`,
      `lightning-input:has(label:text("${label}")) input`,
      `input[aria-label*="${label}"]`,
      `input[placeholder*="${label}"]`,
      `textarea[aria-label*="${label}"]`
    ];

    for (const selector of selectors) {
      try {
        const element = page.locator(selector).first();
        await element.waitFor({ state: 'visible', timeout: 5000 });
        await element.clear();
        await element.fill(value);
        return;
      } catch {
        continue;
      }
    }

    throw new Error(`Input field with label "${label}" not found`);
  }

  static async selectFromLightningCombobox(page: Page, label: string, option: string): Promise<void> {
    const comboboxSelectors = [
      `lightning-combobox[data-field="${label}"]`,
      `lightning-combobox:has(label:text("${label}"))`,
      `[data-target-selection-name*="${label}"]`
    ];

    for (const selector of comboboxSelectors) {
      try {
        const combobox = page.locator(selector).first();
        await combobox.waitFor({ state: 'visible', timeout: 5000 });
        await combobox.click();
        break;
      } catch {
        continue;
      }
    }

    await page.waitForSelector('lightning-base-combobox-item, [role="option"]', { state: 'visible' });
    await page.locator(`lightning-base-combobox-item:has-text("${option}"), [role="option"]:has-text("${option}")`).click();
    await this.waitForLightningSpinner(page);
  }

  static async waitForToastMessage(page: Page, messageType: 'success' | 'error' | 'warning' | 'info' = 'success'): Promise<string> {
    const toast = page.locator(`.slds-theme_${messageType}, .toastMessage.slds-theme--${messageType}, .slds-notify_toast.slds-theme_${messageType}`);
    await toast.waitFor({ state: 'visible', timeout: 15000 });
    const message = await toast.textContent();
    return message || '';
  }

  static async navigateToApp(page: Page, appName: string): Promise<void> {
    await page.click('.slds-icon-waffle, [data-aura-class="uiButton"] .slds-icon-waffle');
    await page.waitForSelector('.slds-app-launcher__content', { state: 'visible' });

    const searchInput = page.locator('input[placeholder*="Search apps"]');
    if (await searchInput.isVisible()) {
      await searchInput.fill(appName);
      await page.waitForTimeout(1000);
    }

    await page.click(`[data-name="${appName}"], .slds-app-launcher__tile:has-text("${appName}")`);
    await this.waitForPageLoad(page);
  }

  static async navigateToObject(page: Page, objectName: string): Promise<void> {
    await page.goto(`/lightning/o/${objectName}/list`);
    await this.waitForPageLoad(page);
  }

  static async login(page: Page, username: string, password: string): Promise<void> {
    await page.fill('#username', username);
    await page.fill('#password', password);
    await page.click('#Login');
    await this.waitForPageLoad(page);
  }

  static async handleLightningErrors(page: Page): Promise<string[]> {
    const errors: string[] = [];

    const errorSelectors = [
      '.slds-theme_error',
      '.forcePageError', 
      '.slds-notify_toast.slds-theme_error',
      '.slds-has-error .slds-form-element__help'
    ];

    for (const selector of errorSelectors) {
      const elements = page.locator(selector);
      const count = await elements.count();

      for (let i = 0; i < count; i++) {
        const text = await elements.nth(i).textContent();
        if (text) errors.push(text.trim());
      }
    }

    return errors;
  }

  static async searchGlobally(page: Page, searchTerm: string): Promise<void> {
    const searchSelectors = [
      '[data-target="GlobalSearch"] input',
      'input[placeholder*="Search"]',
      '.globalSearchInputWrapper input'
    ];

    for (const selector of searchSelectors) {
      try {
        const searchInput = page.locator(selector).first();
        await searchInput.waitFor({ state: 'visible', timeout: 5000 });
        await searchInput.fill(searchTerm);
        await page.keyboard.press('Enter');
        await this.waitForPageLoad(page);
        return;
      } catch {
        continue;
      }
    }

    throw new Error('Global search input not found');
  }
}
import { APIRequestContext, request } from '@playwright/test';
import { getEnvironmentConfig } from '../../config/environments';
import * as dotenv from 'dotenv';

dotenv.config();

export interface SalesforceAuthResponse {
  access_token: string;
  instance_url: string;
  id: string;
  token_type: string;
  issued_at: string;
  signature: string;
}

export class ApiClient {
  private apiContext: APIRequestContext | null = null;
  private authInfo: SalesforceAuthResponse | null = null;

  async authenticate(): Promise<SalesforceAuthResponse> {
    if (this.authInfo) return this.authInfo;

    const env = process.env.TEST_ENV || 'dev';
    const envConfig = getEnvironmentConfig();

    try {
      const authContext = await request.newContext();
      const response = await authContext.post(envConfig.authUrl, {
        form: {
          grant_type: 'password',
          client_id: process.env[`${env.toUpperCase()}_CLIENT_ID`] || '',
          client_secret: process.env[`${env.toUpperCase()}_CLIENT_SECRET`] || '',
          username: process.env[`${env.toUpperCase()}_USERNAME`] || '',
          password: (process.env[`${env.toUpperCase()}_PASSWORD`] || '') + (process.env[`${env.toUpperCase()}_SECURITY_TOKEN`] || ''),
        },
      });

      if (!response.ok()) {
        throw new Error(`Authentication failed: ${response.status()} ${await response.text()}`);
      }

      this.authInfo = await response.json();
      await authContext.dispose();
      return this.authInfo;
    } catch (error) {
      throw new Error(`Salesforce authentication failed: ${error}`);
    }
  }

  async getApiContext(): Promise<APIRequestContext> {
    await this.authenticate();

    if (!this.apiContext) {
      this.apiContext = await request.newContext({
        baseURL: this.authInfo!.instance_url,
        extraHTTPHeaders: {
          'Authorization': `Bearer ${this.authInfo!.access_token}`,
          'Content-Type': 'application/json',
        },
        timeout: getEnvironmentConfig().timeout.api,
      });
    }

    return this.apiContext;
  }

  getAuthInfo(): SalesforceAuthResponse {
    if (!this.authInfo) {
      throw new Error('Not authenticated. Call authenticate() first.');
    }
    return this.authInfo;
  }

  async dispose(): Promise<void> {
    if (this.apiContext) {
      await this.apiContext.dispose();
      this.apiContext = null;
    }
    this.authInfo = null;
  }
}
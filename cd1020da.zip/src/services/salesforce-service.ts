import { APIRequestContext } from '@playwright/test';
import { SalesforceApiHelpers } from '../utils/api-helpers';

export interface SObjectRecord {
  Id?: string;
  [key: string]: any;
}

export interface PolicyRecord extends SObjectRecord {
  Name: string;
  Policy_Type__c: 'Property' | 'Casualty' | 'Auto';
  Coverage_Amount__c: number;
  Deductible__c: number;
  Effective_Date__c: string;
  Status__c: 'Active' | 'Pending' | 'Cancelled';
}

export interface AccountRecord extends SObjectRecord {
  Name: string;
  Type: string;
  Industry: string;
  Phone?: string;
  Website?: string;
}

export class SalesforceService {
  constructor(
    private apiContext: APIRequestContext,
    private instanceUrl: string
  ) {}

  async createAccount(accountData: Partial<AccountRecord>): Promise<string> {
    const result = await SalesforceApiHelpers.createRecord(
      this.apiContext,
      'Account',
      accountData,
      this.instanceUrl
    );
    return result.id;
  }

  async createPolicy(policyData: Partial<PolicyRecord>): Promise<string> {
    const result = await SalesforceApiHelpers.createRecord(
      this.apiContext,
      'Policy__c',
      policyData,
      this.instanceUrl
    );
    return result.id;
  }

  async getAccount(accountId: string): Promise<AccountRecord> {
    return await SalesforceApiHelpers.getRecord(
      this.apiContext,
      'Account',
      accountId,
      ['Id', 'Name', 'Type', 'Industry', 'Phone', 'Website'],
      this.instanceUrl
    ) as AccountRecord;
  }

  async findAccountByName(accountName: string): Promise<SObjectRecord | null> {
    return await SalesforceApiHelpers.findRecordByField(
      this.apiContext,
      'Account',
      'Name',
      accountName,
      this.instanceUrl
    );
  }

  async createBulkPolicies(policiesData: Partial<PolicyRecord>[]): Promise<any[]> {
    return await SalesforceApiHelpers.createBulkRecords(
      this.apiContext,
      'Policy__c',
      policiesData,
      this.instanceUrl
    );
  }
}
import { Page } from '@playwright/test';
import { BasePage } from './base-page';
import { PolicyData } from '../utils/data-factory';
import { SalesforceHelpers } from '../utils/salesforce-helpers';

export class PolicyPage extends BasePage {
  constructor(page: Page) {
    super(page);
  }

  async navigateToPolicies(): Promise<void> {
    await SalesforceHelpers.navigateToObject(this.page, 'Policy__c');
  }

  async clickNew(): Promise<void> {
    const newButton = this.page.locator('a[title="New"], button:has-text("New")').first();
    await newButton.click();
    await this.waitForPageLoad();
  }

  async createPolicy(policyData: PolicyData): Promise<string> {
    await this.fillInput('Name', policyData.Name);
    await this.selectFromCombobox('Policy Type', policyData.Policy_Type__c);
    await this.fillInput('Coverage Amount', policyData.Coverage_Amount__c.toString());
    await this.fillInput('Deductible', policyData.Deductible__c.toString());
    await this.fillInput('Effective Date', policyData.Effective_Date__c);

    if (policyData.Status__c) {
      await this.selectFromCombobox('Status', policyData.Status__c);
    }

    await this.clickButton('Save');
    await this.waitForToast('success');

    // Extract record ID from URL
    await this.page.waitForTimeout(2000);
    const url = this.page.url();
    const recordId = url.match(/\/([a-zA-Z0-9]{15,18})\/view/)?.[1] || '';

    return recordId;
  }

  async searchPolicy(policyName: string): Promise<void> {
    await SalesforceHelpers.searchGlobally(this.page, policyName);
  }

  async openPolicy(policyName: string): Promise<void> {
    await this.page.click(`tr:has-text("${policyName}") a, a:has-text("${policyName}")`);
    await this.waitForPageLoad();
  }

  async editPolicy(updates: Partial<PolicyData>): Promise<void> {
    await this.clickButton('Edit');

    for (const [field, value] of Object.entries(updates)) {
      if (field.includes('Type') || field.includes('Status')) {
        await this.selectFromCombobox(field.replace('__c', '').replace('_', ' '), value as string);
      } else {
        await this.fillInput(field.replace('__c', '').replace('_', ' '), value.toString());
      }
    }

    await this.clickButton('Save');
    await this.waitForToast('success');
  }

  async getPolicyDetails(): Promise<any> {
    await this.waitForPageLoad();

    const details: any = {};

    try {
      // Try to get policy details from the record page
      const nameElement = this.page.locator('.slds-page-header__title, [data-target-selection-name*="Name"] .slds-form-element__static').first();
      if (await nameElement.isVisible()) {
        details.name = await nameElement.textContent();
      }
    } catch (error) {
      console.warn('Could not extract policy details:', error);
    }

    return details;
  }
}
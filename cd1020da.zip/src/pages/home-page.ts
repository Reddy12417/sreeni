import { Page } from '@playwright/test';
import { BasePage } from './base-page';
import { SalesforceHelpers } from '../utils/salesforce-helpers';

export class HomePage extends BasePage {
  constructor(page: Page) {
    super(page);
  }

  async searchGlobally(searchTerm: string): Promise<void> {
    await SalesforceHelpers.searchGlobally(this.page, searchTerm);
  }

  async openApp(appName: string): Promise<void> {
    await this.navigateToApp(appName);
  }

  async isLoaded(): Promise<boolean> {
    try {
      await this.page.waitForSelector('.slds-icon-waffle', { timeout: 10000 });
      return true;
    } catch {
      return false;
    }
  }

  async logout(): Promise<void> {
    try {
      const userMenu = this.page.locator('.slds-avatar, .profileTrigger');
      await userMenu.click();
      await this.page.click('a:has-text("Log Out")');
    } catch (error) {
      console.warn('Logout failed:', error);
    }
  }
}
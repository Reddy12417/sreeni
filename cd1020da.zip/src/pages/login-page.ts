import { Page } from '@playwright/test';
import { BasePage } from './base-page';

export class LoginPage extends BasePage {
  private readonly selectors = {
    username: '#username',
    password: '#password',
    loginButton: '#Login',
    errorMessage: '.loginError, #error'
  };

  constructor(page: Page) {
    super(page);
  }

  async navigateToLogin(url: string): Promise<void> {
    await this.page.goto(url);
    await this.page.waitForSelector(this.selectors.username);
  }

  async login(username: string, password: string): Promise<void> {
    await this.page.fill(this.selectors.username, username);
    await this.page.fill(this.selectors.password, password);
    await this.page.click(this.selectors.loginButton);
    await this.waitForPageLoad();
  }

  async getLoginError(): Promise<string> {
    try {
      await this.page.waitForSelector(this.selectors.errorMessage, { timeout: 5000 });
      return await this.page.textContent(this.selectors.errorMessage) || '';
    } catch {
      return '';
    }
  }

  async isLoggedIn(): Promise<boolean> {
    try {
      await this.page.waitForSelector('.slds-icon-waffle', { timeout: 10000 });
      return true;
    } catch {
      return false;
    }
  }
}
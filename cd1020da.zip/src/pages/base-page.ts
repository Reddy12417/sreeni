import { Page } from '@playwright/test';
import { SalesforceHelpers } from '../utils/salesforce-helpers';

export abstract class BasePage {
  protected page: Page;

  constructor(page: Page) {
    this.page = page;
  }

  async waitForPageLoad(): Promise<void> {
    await SalesforceHelpers.waitForPageLoad(this.page);
  }

  async navigateToApp(appName: string): Promise<void> {
    await SalesforceHelpers.navigateToApp(this.page, appName);
  }

  async clickButton(buttonText: string): Promise<void> {
    await SalesforceHelpers.clickLightningButton(this.page, buttonText);
  }

  async fillInput(label: string, value: string): Promise<void> {
    await SalesforceHelpers.fillLightningInput(this.page, label, value);
  }

  async selectFromCombobox(label: string, option: string): Promise<void> {
    await SalesforceHelpers.selectFromLightningCombobox(this.page, label, option);
  }

  async waitForToast(messageType: 'success' | 'error' | 'warning' | 'info' = 'success'): Promise<string> {
    return await SalesforceHelpers.waitForToastMessage(this.page, messageType);
  }

  async getErrors(): Promise<string[]> {
    return await SalesforceHelpers.handleLightningErrors(this.page);
  }

  async takeScreenshot(name: string): Promise<void> {
    await this.page.screenshot({ 
      path: `reports/screenshots/${name}-${Date.now()}.png`,
      fullPage: true 
    });
  }
}
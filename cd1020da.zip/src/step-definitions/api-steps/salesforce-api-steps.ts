import { Given, When, Then, DataTable } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { World } from '../../support/world';
import { SalesforceApiHelpers } from '../../utils/api-helpers';
import { SalesforceService } from '../../services/salesforce-service';
import { DataFactory } from '../../utils/data-factory';

Given('I have valid Salesforce API authentication', async function (this: World) {
  const auth = await this.apiClient.authenticate();
  expect(auth.access_token).toBeTruthy();
  expect(auth.instance_url).toBeTruthy();
});

Given('I have created an Account via API', async function (this: World) {
  const accountData = DataFactory.createAccount();
  const apiContext = await this.apiClient.getApiContext();
  const auth = this.apiClient.getAuthInfo();

  const service = new SalesforceService(apiContext, auth.instance_url);
  const accountId = await service.createAccount(accountData);

  this.addCreatedRecord('Account', accountId);
  this.setTestData('accountId', accountId);
  this.setTestData('accountName', accountData.Name);
});

Given('I have prepared test data for {int} policies', async function (this: World, count: number) {
  const bulkPolicies = DataFactory.createBulkData(() => DataFactory.createPolicy(), count);
  this.setTestData('bulkPolicies', bulkPolicies);
});

Given('I create a policy via API with name {string}', async function (this: World, policyName: string) {
  const policyData = DataFactory.createPolicy({ Name: policyName });
  const apiContext = await this.apiClient.getApiContext();
  const auth = this.apiClient.getAuthInfo();

  const result = await apiContext.post(`${auth.instance_url}/services/data/v58.0/sobjects/Policy__c/`, {
    data: policyData
  });

  expect(result.status()).toBe(201);
  const response = await result.json();

  this.addCreatedRecord('Policy__c', response.id);
  this.setTestData('integrationPolicyName', policyName);
  this.setTestData('integrationPolicyId', response.id);
});

Given('I have multiple policies with different statuses in the system', async function (this: World) {
  const policies = [
    DataFactory.createPolicy({ Status__c: 'Active', Coverage_Amount__c: 1500000 }),
    DataFactory.createPolicy({ Status__c: 'Active', Coverage_Amount__c: 800000 }),
    DataFactory.createPolicy({ Status__c: 'Pending', Coverage_Amount__c: 1200000 }),
    DataFactory.createPolicy({ Status__c: 'Active', Coverage_Amount__c: 2000000 })
  ];

  const apiContext = await this.apiClient.getApiContext();
  const auth = this.apiClient.getAuthInfo();

  for (const policy of policies) {
    const result = await apiContext.post(`${auth.instance_url}/services/data/v58.0/sobjects/Policy__c/`, {
      data: policy
    });
    const response = await result.json();
    this.addCreatedRecord('Policy__c', response.id);

    if (policy.Status__c === 'Active' && policy.Coverage_Amount__c > 1000000) {
      this.setTestData('expectedPolicyId', response.id);
    }
  }
});

Given('I have created related Account, Policy, and Contact records', async function (this: World) {
  const apiContext = await this.apiClient.getApiContext();
  const auth = this.apiClient.getAuthInfo();

  // Create Account
  const accountData = DataFactory.createAccount();
  const accountResult = await apiContext.post(`${auth.instance_url}/services/data/v58.0/sobjects/Account/`, {
    data: accountData
  });
  const account = await accountResult.json();
  this.addCreatedRecord('Account', account.id);

  // Create Policy linked to Account (if Policy has Account lookup)
  const policyData = DataFactory.createPolicy();
  const policyResult = await apiContext.post(`${auth.instance_url}/services/data/v58.0/sobjects/Policy__c/`, {
    data: policyData
  });
  const policy = await policyResult.json();
  this.addCreatedRecord('Policy__c', policy.id);

  // Create Contact linked to Account
  const contactData = DataFactory.createContact(account.id);
  const contactResult = await apiContext.post(`${auth.instance_url}/services/data/v58.0/sobjects/Contact/`, {
    data: contactData
  });
  const contact = await contactResult.json();
  this.addCreatedRecord('Contact', contact.id);

  this.setTestData('relatedAccountId', account.id);
  this.setTestData('relatedPolicyId', policy.id);
  this.setTestData('relatedContactId', contact.id);
});

Given('I create a new policy record via API', async function (this: World) {
  const policyData = DataFactory.createPolicy();
  const apiContext = await this.apiClient.getApiContext();
  const auth = this.apiClient.getAuthInfo();

  this.apiResponse = await apiContext.post(`${auth.instance_url}/services/data/v58.0/sobjects/Policy__c/`, {
    data: policyData
  });

  const response = await this.apiResponse.json();
  this.addCreatedRecord('Policy__c', response.id);
  this.setTestData('auditPolicyId', response.id);
});

Given('I have multiple concurrent API requests prepared', async function (this: World) {
  const accounts = DataFactory.createBulkData(() => DataFactory.createAccount(), 3);
  const policies = DataFactory.createBulkData(() => DataFactory.createPolicy(), 3);

  this.setTestData('concurrentAccounts', accounts);
  this.setTestData('concurrentPolicies', policies);
});

When('I send a POST request to create an Account with the following data:', async function (this: World, dataTable: DataTable) {
  const accountData = dataTable.rowsHash();
  const apiContext = await this.apiClient.getApiContext();
  const auth = this.apiClient.getAuthInfo();

  this.apiResponse = await apiContext.post(`${auth.instance_url}/services/data/v58.0/sobjects/Account/`, {
    data: accountData
  });

  if (this.apiResponse.status() === 201) {
    const response = await this.apiResponse.json();
    this.addCreatedRecord('Account', response.id);
    this.setTestData('createdAccountData', accountData);
  }
});

When('I send a POST request to create a Policy with the following data:', async function (this: World, dataTable: DataTable) {
  const policyData = dataTable.rowsHash();
  const apiContext = await this.apiClient.getApiContext();
  const auth = this.apiClient.getAuthInfo();

  // Convert string values to appropriate types
  const processedData = {
    ...policyData,
    Coverage_Amount__c: parseInt(policyData.Coverage_Amount__c),
    Deductible__c: parseInt(policyData.Deductible__c)
  };

  this.apiResponse = await apiContext.post(`${auth.instance_url}/services/data/v58.0/sobjects/Policy__c/`, {
    data: processedData
  });

  if (this.apiResponse.status() === 201) {
    const response = await this.apiResponse.json();
    this.addCreatedRecord('Policy__c', response.id);
    this.setTestData('createdPolicyData', processedData);
  }
});

When('I send a bulk create request using Composite API', async function (this: World) {
  const bulkPolicies = this.getTestData('bulkPolicies');
  const apiContext = await this.apiClient.getApiContext();
  const auth = this.apiClient.getAuthInfo();

  const bulkResults = await SalesforceApiHelpers.createBulkRecords(
    apiContext,
    'Policy__c',
    bulkPolicies,
    auth.instance_url
  );

  this.setTestData('bulkResults', bulkResults);

  // Track successful creations for cleanup
  bulkResults.forEach((result: any) => {
    if (result.httpStatusCode === 201) {
      this.addCreatedRecord('Policy__c', result.body.id);
    }
  });
});

When('I attempt to create a Policy with invalid data:', async function (this: World, dataTable: DataTable) {
  const invalidDataRows = dataTable.hashes();
  const apiContext = await this.apiClient.getApiContext();
  const auth = this.apiClient.getAuthInfo();

  // Test the first invalid data scenario
  const testRow = invalidDataRows[0];
  const invalidData: any = { Name: 'INVALID-TEST-POLICY' };

  if (testRow.Field === 'Coverage_Amount__c') {
    invalidData[testRow.Field] = parseInt(testRow['Invalid Value']);
  } else {
    invalidData[testRow.Field] = testRow['Invalid Value'];
  }

  this.apiResponse = await apiContext.post(`${auth.instance_url}/services/data/v58.0/sobjects/Policy__c/`, {
    data: invalidData
  });
});

When('I execute a SOQL query to find all active policies with coverage over 1000000', async function (this: World) {
  const soql = "SELECT Id, Name, Policy_Type__c, Status__c, Coverage_Amount__c FROM Policy__c WHERE Status__c = 'Active' AND Coverage_Amount__c > 1000000 LIMIT 10";
  const apiContext = await this.apiClient.getApiContext();
  const auth = this.apiClient.getAuthInfo();

  const startTime = Date.now();
  const result = await SalesforceApiHelpers.query(apiContext, soql, auth.instance_url);
  const queryTime = Date.now() - startTime;

  this.setTestData('queryResult', result);
  this.setTestData('queryTime', queryTime);
});

When('I query the relationships using SOQL joins', async function (this: World) {
  const accountId = this.getTestData('relatedAccountId');
  const soql = `SELECT Id, Name, (SELECT Id, FirstName, LastName FROM Contacts) FROM Account WHERE Id = '${accountId}'`;

  const apiContext = await this.apiClient.getApiContext();
  const auth = this.apiClient.getAuthInfo();

  const result = await SalesforceApiHelpers.query(apiContext, soql, auth.instance_url);
  this.setTestData('relationshipQueryResult', result);
});

When('I retrieve the policy details including audit fields', async function (this: World) {
  const policyId = this.getTestData('auditPolicyId');
  const apiContext = await this.apiClient.getApiContext();
  const auth = this.apiClient.getAuthInfo();

  const auditFields = ['Id', 'Name', 'CreatedDate', 'CreatedById', 'LastModifiedDate', 'SystemModstamp'];
  this.apiResponse = await apiContext.get(`${auth.instance_url}/services/data/v58.0/sobjects/Policy__c/${policyId}?fields=${auditFields.join(',')}`);
});

When('I execute simultaneous create operations for different objects', async function (this: World) {
  const accounts = this.getTestData('concurrentAccounts');
  const policies = this.getTestData('concurrentPolicies');
  const apiContext = await this.apiClient.getApiContext();
  const auth = this.apiClient.getAuthInfo();

  const accountPromises = accounts.map((account: any) =>
    apiContext.post(`${auth.instance_url}/services/data/v58.0/sobjects/Account/`, { data: account })
  );

  const policyPromises = policies.map((policy: any) =>
    apiContext.post(`${auth.instance_url}/services/data/v58.0/sobjects/Policy__c/`, { data: policy })
  );

  const allResults = await Promise.all([...accountPromises, ...policyPromises]);
  this.setTestData('concurrentResults', allResults);

  // Track created records for cleanup
  for (let i = 0; i < allResults.length; i++) {
    if (allResults[i].status() === 201) {
      const response = await allResults[i].json();
      const objectType = i < accounts.length ? 'Account' : 'Policy__c';
      this.addCreatedRecord(objectType, response.id);
    }
  }
});

When('I search for the policy in Salesforce user interface', async function (this: World) {
  const policyName = this.getTestData('integrationPolicyName');

  await this.page.goto('/lightning/o/Policy__c/list');
  await this.page.waitForLoadState('networkidle');

  const searchInput = this.page.locator('input[placeholder*="Search"]').first();
  await searchInput.fill(policyName);
  await this.page.keyboard.press('Enter');
  await this.page.waitForLoadState('networkidle');
});

Then('the API response status should be {int}', async function (this: World, expectedStatus: number) {
  expect(this.apiResponse.status()).toBe(expectedStatus);
});

Then('the response should contain a valid record ID', async function (this: World) {
  const response = await this.apiResponse.json();
  expect(response.id).toBeTruthy();
  expect(response.id).toMatch(/^[a-zA-Z0-9]{15,18}$/);
});

Then('I should be able to retrieve the account details', async function (this: World) {
  const response = await this.apiResponse.json();
  const apiContext = await this.apiClient.getApiContext();
  const auth = this.apiClient.getAuthInfo();

  const getResponse = await apiContext.get(`${auth.instance_url}/services/data/v58.0/sobjects/Account/${response.id}`);
  expect(getResponse.status()).toBe(200);
});

Then('the account data should match the created values', async function (this: World) {
  const response = await this.apiResponse.json();
  const originalData = this.getTestData('createdAccountData');
  const apiContext = await this.apiClient.getApiContext();
  const auth = this.apiClient.getAuthInfo();

  const accountData = await apiContext.get(`${auth.instance_url}/services/data/v58.0/sobjects/Account/${response.id}`);
  const account = await accountData.json();

  expect(account.Name).toBe(originalData.Name);
  expect(account.Type).toBe(originalData.Type);
  expect(account.Industry).toBe(originalData.Industry);
});

Then('the response should contain a valid policy ID', async function (this: World) {
  const response = await this.apiResponse.json();
  expect(response.id).toBeTruthy();
  expect(response.id).toMatch(/^[a-zA-Z0-9]{15,18}$/);
});

Then('the policy should be associated with the account', async function (this: World) {
  // This would depend on your data model having an Account lookup on Policy
  const response = await this.apiResponse.json();
  expect(response.id).toBeTruthy(); // Basic validation
});

Then('I should be able to query the policy via SOQL', async function (this: World) {
  const response = await this.apiResponse.json();
  const apiContext = await this.apiClient.getApiContext();
  const auth = this.apiClient.getAuthInfo();

  const soql = `SELECT Id, Name FROM Policy__c WHERE Id = '${response.id}'`;
  const queryResult = await SalesforceApiHelpers.query(apiContext, soql, auth.instance_url);

  expect(queryResult.records).toHaveLength(1);
  expect(queryResult.records[0].Id).toBe(response.id);
});

Then('all policies should be created successfully', async function (this: World) {
  const bulkResults = this.getTestData('bulkResults');

  bulkResults.forEach((result: any) => {
    expect(result.httpStatusCode).toBe(201);
    expect(result.body.success).toBe(true);
  });
});

Then('I should receive individual responses for each policy', async function (this: World) {
  const bulkResults = this.getTestData('bulkResults');
  const bulkPolicies = this.getTestData('bulkPolicies');

  expect(bulkResults).toHaveLength(bulkPolicies.length);
});

Then('all returned policy IDs should be valid Salesforce IDs', async function (this: World) {
  const bulkResults = this.getTestData('bulkResults');

  bulkResults.forEach((result: any) => {
    expect(result.body.id).toMatch(/^[a-zA-Z0-9]{15,18}$/);
  });
});

Then('the policies should be queryable via SOQL', async function (this: World) {
  const bulkResults = this.getTestData('bulkResults');
  const apiContext = await this.apiClient.getApiContext();
  const auth = this.apiClient.getAuthInfo();

  const policyIds = bulkResults.map((result: any) => result.body.id);
  const soql = `SELECT Id FROM Policy__c WHERE Id IN ('${policyIds.join("','")}'')`;

  const queryResult = await SalesforceApiHelpers.query(apiContext, soql, auth.instance_url);
  expect(queryResult.records).toHaveLength(policyIds.length);
});

Then('the API should return appropriate validation errors', async function (this: World) {
  expect(this.apiResponse.status()).toBeGreaterThanOrEqual(400);
  expect(this.apiResponse.status()).toBeLessThan(500);
});

Then('the error messages should be descriptive and actionable', async function (this: World) {
  const errorResponse = await this.apiResponse.json();
  expect(Array.isArray(errorResponse)).toBe(true);
  expect(errorResponse[0].message).toBeTruthy();
  expect(errorResponse[0].errorCode).toBeTruthy();
});

Then('no partial data should be created in the system', async function (this: World) {
  expect(this.apiResponse.status()).not.toBe(201);
});

Then('I should find the policy record in the UI search results', async function (this: World) {
  const policyName = this.getTestData('integrationPolicyName');
  const policyVisible = await this.page.isVisible(`tr:has-text("${policyName}"), a:has-text("${policyName}")`);
  expect(policyVisible).toBeTruthy();
});

Then('all API-created fields should be properly displayed', async function (this: World) {
  const policyName = this.getTestData('integrationPolicyName');

  // Click on the policy to view details
  await this.page.click(`tr:has-text("${policyName}") a, a:has-text("${policyName}")`);
  await this.page.waitForURL('**/lightning/r/Policy__c/**/view');

  // Verify policy name is displayed
  const pageTitle = await this.page.textContent('.slds-page-header__title, [data-target-selection-name*="Name"]');
  expect(pageTitle).toContain(policyName);
});

Then('the policy should be fully functional in the UI', async function (this: World) {
  const editButtonVisible = await this.page.isVisible('button:has-text("Edit"), a:has-text("Edit")');
  expect(editButtonVisible).toBeTruthy();
});

Then('I should be able to edit the policy through the UI', async function (this: World) {
  const editButton = this.page.locator('button:has-text("Edit"), a:has-text("Edit")').first();
  if (await editButton.isVisible()) {
    await editButton.click();
    const saveButtonVisible = await this.page.isVisible('button:has-text("Save")');
    expect(saveButtonVisible).toBeTruthy();
  }
});

Then('I should receive only policies matching the criteria', async function (this: World) {
  const queryResult = this.getTestData('queryResult');
  expect(queryResult.records).toBeDefined();

  queryResult.records.forEach((record: any) => {
    expect(record.Status__c).toBe('Active');
    expect(record.Coverage_Amount__c).toBeGreaterThan(1000000);
  });
});

Then('each policy record should contain all required fields', async function (this: World) {
  const queryResult = this.getTestData('queryResult');
  const requiredFields = ['Id', 'Name', 'Policy_Type__c', 'Status__c', 'Coverage_Amount__c'];

  queryResult.records.forEach((record: any) => {
    requiredFields.forEach(field => {
      expect(record).toHaveProperty(field);
    });
  });
});

Then('the query should execute within acceptable performance limits', async function (this: World) {
  const queryTime = this.getTestData('queryTime');
  expect(queryTime).toBeLessThan(5000); // 5 seconds
});

Then('the results should be properly formatted', async function (this: World) {
  const queryResult = this.getTestData('queryResult');
  expect(queryResult).toHaveProperty('totalSize');
  expect(queryResult).toHaveProperty('done');
  expect(queryResult).toHaveProperty('records');
  expect(Array.isArray(queryResult.records)).toBe(true);
});

Then('I should receive properly linked related records', async function (this: World) {
  const queryResult = this.getTestData('relationshipQueryResult');
  expect(queryResult.records).toHaveLength(1);

  const account = queryResult.records[0];
  expect(account).toHaveProperty('Contacts');
  expect(account.Contacts).toHaveProperty('records');
});

Then('the parent-child relationships should be intact', async function (this: World) {
  const queryResult = this.getTestData('relationshipQueryResult');
  const account = queryResult.records[0];

  expect(account.Contacts.records.length).toBeGreaterThan(0);
});

Then('all lookup fields should reference valid records', async function (this: World) {
  const queryResult = this.getTestData('relationshipQueryResult');
  const account = queryResult.records[0];

  expect(account.Id).toMatch(/^[a-zA-Z0-9]{15,18}$/);
  account.Contacts.records.forEach((contact: any) => {
    expect(contact.Id).toMatch(/^[a-zA-Z0-9]{15,18}$/);
  });
});

Then('the CreatedDate should be recent and accurate', async function (this: World) {
  const response = await this.apiResponse.json();
  const createdDate = new Date(response.CreatedDate);
  const now = new Date();
  const diffMinutes = (now.getTime() - createdDate.getTime()) / (1000 * 60);

  expect(diffMinutes).toBeLessThan(5); // Within 5 minutes
});

Then('the CreatedById should match the API user', async function (this: World) {
  const response = await this.apiResponse.json();
  expect(response.CreatedById).toBeTruthy();
  expect(response.CreatedById).toMatch(/^[a-zA-Z0-9]{15,18}$/);
});

Then('the LastModifiedDate should equal CreatedDate initially', async function (this: World) {
  const response = await this.apiResponse.json();
  expect(response.LastModifiedDate).toBe(response.CreatedDate);
});

Then('the SystemModstamp should be properly set', async function (this: World) {
  const response = await this.apiResponse.json();
  expect(response.SystemModstamp).toBeTruthy();

  const modstampDate = new Date(response.SystemModstamp);
  expect(modstampDate.getTime()).toBeGreaterThan(0);
});

Then('all requests should be processed successfully', async function (this: World) {
  const results = this.getTestData('concurrentResults');

  results.forEach((result: any) => {
    expect(result.status()).toBe(201);
  });
});

Then('there should be no data corruption or conflicts', async function (this: World) {
  const results = this.getTestData('concurrentResults');

  // Verify all requests succeeded
  const successfulRequests = results.filter((result: any) => result.status() === 201);
  expect(successfulRequests).toHaveLength(results.length);
});

Then('each record should maintain its data integrity', async function (this: World) {
  // Basic verification that concurrent operations completed successfully
  const results = this.getTestData('concurrentResults');
  expect(results).toBeTruthy();
  expect(results.length).toBeGreaterThan(0);
});

Then('the system should handle the load appropriately', async function (this: World) {
  const results = this.getTestData('concurrentResults');

  // All concurrent requests should complete successfully
  const allSuccessful = results.every((result: any) => result.status() === 201);
  expect(allSuccessful).toBe(true);
});
import { Given, When, Then } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { World } from '../../support/world';
import { LoginPage } from '../../pages/login-page';
import { HomePage } from '../../pages/home-page';
import { getEnvironmentConfig } from '../../../config/environments';

Given('I navigate to the Salesforce login page', async function (this: World) {
  const envConfig = getEnvironmentConfig();
  this.loginPage = new LoginPage(this.page);
  await this.loginPage.navigateToLogin(envConfig.webUrl);
});

When('I enter valid login credentials', async function (this: World) {
  const env = process.env.TEST_ENV || 'dev';
  const username = process.env[`${env.toUpperCase()}_USERNAME`];
  const password = process.env[`${env.toUpperCase()}_PASSWORD`];

  if (!username || !password) {
    throw new Error(`Missing credentials for ${env} environment. Please check your .env file.`);
  }

  await this.loginPage.login(username, password);
});

When('I enter invalid login credentials', async function (this: World) {
  await this.page.fill('#username', 'invalid@example.com');
  await this.page.fill('#password', 'wrongpassword');
  await this.page.click('#Login');
  await this.page.waitForTimeout(3000); // Wait for error message
});

When('I navigate to the {string} application', async function (this: World, appName: string) {
  this.homePage = new HomePage(this.page);
  await this.homePage.openApp(appName);
});

Then('I should be redirected to Salesforce home page', async function (this: World) {
  const isLoggedIn = await this.loginPage.isLoggedIn();
  expect(isLoggedIn).toBeTruthy();
});

Then('I should see the application launcher', async function (this: World) {
  const appLauncherVisible = await this.page.isVisible('.slds-icon-waffle');
  expect(appLauncherVisible).toBeTruthy();
});

Then('I should be able to navigate to different apps', async function (this: World) {
  // Test that we can open the app launcher
  await this.page.click('.slds-icon-waffle');
  const appLauncherContent = await this.page.isVisible('.slds-app-launcher__content');
  expect(appLauncherContent).toBeTruthy();
});

Then('I should see an authentication error message', async function (this: World) {
  const errorMessage = await this.loginPage.getLoginError();
  expect(errorMessage).toBeTruthy();
  expect(errorMessage.toLowerCase()).toMatch(/invalid|incorrect|error/);
});

Then('I should remain on the login page', async function (this: World) {
  const isOnLoginPage = await this.page.isVisible('#username');
  expect(isOnLoginPage).toBeTruthy();
});

Then('the login form should be accessible for retry', async function (this: World) {
  const usernameField = await this.page.isEnabled('#username');
  const passwordField = await this.page.isEnabled('#password');
  const loginButton = await this.page.isEnabled('#Login');

  expect(usernameField).toBeTruthy();
  expect(passwordField).toBeTruthy();
  expect(loginButton).toBeTruthy();
});

Then('I should see the Policy Management interface', async function (this: World) {
  await this.page.waitForURL('**/lightning/o/Policy__c/**', { timeout: 30000 });

  const pageTitle = await this.page.textContent('.slds-page-header__title, .uiOutputText');
  expect(pageTitle).toMatch(/policies|policy/i);
});

Then('I should be able to access policy creation features', async function (this: World) {
  const newButtonVisible = await this.page.isVisible('a[title="New"], button:has-text("New")');
  expect(newButtonVisible).toBeTruthy();
});
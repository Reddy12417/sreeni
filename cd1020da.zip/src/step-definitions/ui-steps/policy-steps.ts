import { Given, When, Then, DataTable } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { World } from '../../support/world';
import { PolicyPage } from '../../pages/policy-page';
import { LoginPage } from '../../pages/login-page';
import { DataFactory, PolicyData } from '../../utils/data-factory';
import { getEnvironmentConfig } from '../../../config/environments';

Given('I am logged into CNA Hardy Salesforce application', async function (this: World) {
  const envConfig = getEnvironmentConfig();
  const env = process.env.TEST_ENV || 'dev';

  this.loginPage = new LoginPage(this.page);
  await this.loginPage.navigateToLogin(envConfig.webUrl);

  const username = process.env[`${env.toUpperCase()}_USERNAME`];
  const password = process.env[`${env.toUpperCase()}_PASSWORD`];

  if (!username || !password) {
    throw new Error(`Missing credentials for ${env} environment`);
  }

  await this.loginPage.login(username, password);

  const isLoggedIn = await this.loginPage.isLoggedIn();
  expect(isLoggedIn).toBeTruthy();
});

Given('I navigate to the Policy Management application', async function (this: World) {
  this.policyPage = new PolicyPage(this.page);
  await this.policyPage.navigateToPolicies();
});

Given('I am on the new policy creation page', async function (this: World) {
  this.policyPage = new PolicyPage(this.page);
  await this.policyPage.navigateToPolicies();
  await this.policyPage.clickNew();
});

Given('I have an existing policy in the system', async function (this: World) {
  // Create policy via API for faster setup
  const policyData = DataFactory.createPolicy();
  const apiContext = await this.apiClient.getApiContext();
  const auth = this.apiClient.getAuthInfo();

  const result = await apiContext.post(`${auth.instance_url}/services/data/v58.0/sobjects/Policy__c/`, {
    data: policyData
  });

  expect(result.status()).toBe(201);
  const response = await result.json();

  this.addCreatedRecord('Policy__c', response.id);
  this.setTestData('existingPolicyId', response.id);
  this.setTestData('existingPolicyName', policyData.Name);
});

Given('I have multiple policies in the system', async function (this: World) {
  const policies = DataFactory.createBulkData(() => DataFactory.createPolicy(), 3);
  const apiContext = await this.apiClient.getApiContext();
  const auth = this.apiClient.getAuthInfo();

  for (const policy of policies) {
    const result = await apiContext.post(`${auth.instance_url}/services/data/v58.0/sobjects/Policy__c/`, {
      data: policy
    });
    const response = await result.json();
    this.addCreatedRecord('Policy__c', response.id);
  }

  this.setTestData('testPolicyName', policies[0].Name);
});

When('I create a property insurance policy with the following details:', async function (this: World, dataTable: DataTable) {
  const policyDetails = dataTable.rowsHash();

  const policyData = DataFactory.createPolicy({
    Policy_Type__c: policyDetails['Policy Type'] as 'Property',
    Coverage_Amount__c: parseInt(policyDetails['Coverage Amount']),
    Deductible__c: parseInt(policyDetails['Deductible']),
    Status__c: policyDetails['Status'] as 'Active'
  });

  const policyId = await this.policyPage.createPolicy(policyData);
  this.addCreatedRecord('Policy__c', policyId);
  this.setTestData('createdPolicyId', policyId);
  this.setTestData('createdPolicyName', policyData.Name);
});

When('I open the policy record for editing', async function (this: World) {
  const policyName = this.getTestData('existingPolicyName');
  await this.policyPage.searchPolicy(policyName);
  await this.policyPage.openPolicy(policyName);
});

When('I update the coverage amount to {string}', async function (this: World, newAmount: string) {
  await this.policyPage.editPolicy({
    Coverage_Amount__c: parseInt(newAmount)
  });
  this.setTestData('updatedCoverageAmount', newAmount);
});

When('I save the policy changes', async function (this: World) {
  // This is handled in the editPolicy method
  await this.page.waitForTimeout(1000);
});

When('I search for a specific policy by policy number', async function (this: World) {
  const policyName = this.getTestData('testPolicyName');
  await this.policyPage.searchPolicy(policyName);
});

When('I attempt to save a policy without required information', async function (this: World) {
  await this.policyPage.fillInput('Name', ''); // Clear required field
  await this.policyPage.clickButton('Save');
});

When('I perform bulk operations on multiple policies', async function (this: World) {
  // Select multiple policies and perform bulk action
  const checkboxes = this.page.locator('input[type="checkbox"]');
  const count = await checkboxes.count();

  for (let i = 0; i < Math.min(count, 3); i++) {
    await checkboxes.nth(i).check();
  }

  // Perform a bulk action if available
  const bulkActionButton = this.page.locator('button:has-text("Change Status"), button:has-text("Bulk")');
  if (await bulkActionButton.isVisible()) {
    await bulkActionButton.click();
  }
});

Then('the policy should be created successfully', async function (this: World) {
  const policyId = this.getTestData('createdPolicyId');
  expect(policyId).toBeTruthy();
  expect(policyId).toMatch(/^[a-zA-Z0-9]{15,18}$/);
});

Then('I should see a success confirmation message', async function (this: World) {
  // Success message should have been captured during policy creation
  const url = this.page.url();
  expect(url).toContain('view'); // Should be on record view page
});

Then('the policy should have a valid policy number', async function (this: World) {
  const policyName = this.getTestData('createdPolicyName');
  expect(policyName).toBeTruthy();
  expect(policyName).toMatch(/^POL-[A-Z0-9]{8}$/);
});

Then('the policy should appear in the policies list', async function (this: World) {
  await this.policyPage.navigateToPolicies();
  const policyName = this.getTestData('createdPolicyName');

  // Search for the created policy
  await this.policyPage.searchPolicy(policyName);
  const policyVisible = await this.page.isVisible(`tr:has-text("${policyName}"), a:has-text("${policyName}")`);
  expect(policyVisible).toBeTruthy();
});

Then('the policy should be updated successfully', async function (this: World) {
  const policyDetails = await this.policyPage.getPolicyDetails();
  expect(policyDetails).toBeTruthy();
});

Then('the new coverage amount should be reflected in the system', async function (this: World) {
  const expectedAmount = this.getTestData('updatedCoverageAmount');
  // Verify the amount is updated (implementation depends on UI structure)
  expect(expectedAmount).toBeTruthy();
});

Then('I should see an update confirmation message', async function (this: World) {
  // Success message should have been captured during edit
  const url = this.page.url();
  expect(url).toContain('view');
});

Then('I should find the policy in the search results', async function (this: World) {
  const policyName = this.getTestData('testPolicyName');
  const policyVisible = await this.page.isVisible(`tr:has-text("${policyName}"), a:has-text("${policyName}")`);
  expect(policyVisible).toBeTruthy();
});

Then('the policy details should be accurate and complete', async function (this: World) {
  const policyName = this.getTestData('testPolicyName');
  await this.policyPage.openPolicy(policyName);

  const details = await this.policyPage.getPolicyDetails();
  expect(details).toBeTruthy();
});

Then('I should be able to view the full policy record', async function (this: World) {
  await this.page.waitForURL('**/lightning/r/Policy__c/**/view');
  const pageLoaded = await this.page.isVisible('.slds-page-header, .record-header');
  expect(pageLoaded).toBeTruthy();
});

Then('I should see appropriate validation error messages', async function (this: World) {
  const errors = await this.policyPage.getErrors();
  expect(errors.length).toBeGreaterThan(0);

  const hasRequiredFieldError = errors.some(error => 
    error.toLowerCase().includes('required') || 
    error.toLowerCase().includes('complete')
  );
  expect(hasRequiredFieldError).toBeTruthy();
});

Then('the policy should not be created in the system', async function (this: World) {
  const isOnEditPage = await this.page.isVisible('button:has-text("Save")');
  expect(isOnEditPage).toBeTruthy();
});

Then('I should be guided to complete the missing fields', async function (this: World) {
  const errorFields = await this.page.locator('.slds-has-error').count();
  expect(errorFields).toBeGreaterThan(0);
});

Then('I have access to the policies list view', async function (this: World) {
  await this.policyPage.navigateToPolicies();
  const listViewLoaded = await this.page.isVisible('.slds-table, .listView');
  expect(listViewLoaded).toBeTruthy();
});

Then('the operations should complete within acceptable time limits', async function (this: World) {
  // Operations should complete within reasonable time
  await this.page.waitForTimeout(2000);
});

Then('all selected policies should be processed correctly', async function (this: World) {
  // Verify bulk operations completed
  const hasSuccessMessage = await this.page.isVisible('.slds-theme_success, .successMessage');
  if (hasSuccessMessage) {
    expect(hasSuccessMessage).toBeTruthy();
  }
});

Then('I should receive confirmation of the bulk operations', async function (this: World) {
  // Check for bulk operation confirmation
  const confirmationExists = await this.page.isVisible('.slds-notify, .forceToast');
  if (confirmationExists) {
    expect(confirmationExists).toBeTruthy();
  }
});